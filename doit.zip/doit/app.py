from flask import Flask, render_template, request, redirect, url_for
from pymongo import MongoClient
import os

app = Flask(__name__)

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client['project_database']
projects_collection = db['projects']

# Route for the index page
@app.route('/')
def index():
    return render_template('index.html')

# Route to upload a project
@app.route('/upload_project')
def upload_project():
    return render_template('profile_page.html')

# Route to handle form submission
@app.route('/submit_project', methods=['POST'])
def submit_project():
    title = request.form['title']
    tagline = request.form['tagline']
    Team_members = request.form['Team_members']
    project_guide = request.form['project_guide']
    Technology_used = request.form['Technology_used']
    project_url = request.form['project_url']
    institution_name = request.form['institution_name']
    domain = request.form['domain']
    
    # Save project image and demo video if they exist
    project_image = request.files.get('project_image')
    demo_video = request.files.get('demo_video')
    
    # Save files
    image_filename = None
    video_filename = None
    if project_image:
        image_filename = os.path.join('static/uploads', project_image.filename)
        project_image.save(image_filename)
    if demo_video:
        video_filename = os.path.join('static/uploads', demo_video.filename)
        demo_video.save(video_filename)

    # Save project data in the MongoDB database
    project_data = {
        'title': title,
        'tagline': tagline,
        'Team_members' : Team_members,
        'project_guide': project_guide,
        'Technology_used': Technology_used,
        'project_url': project_url,
        'institution_name': institution_name,
        'domain': domain,
        'project_image': image_filename,
        'demo_video': video_filename
    }
    
    projects_collection.insert_one(project_data)
    return redirect(url_for('index'))

# Route to show projects by institution
@app.route('/projects/<institution_name>', methods=['GET'])
def show_institution_projects(institution_name):
    domain_filter = request.args.get('domain')  # Get the domain filter from the URL query string

    # Fetch projects for the selected institution
    if domain_filter:
        projects = list(projects_collection.find({'institution_name': institution_name, 'domain': domain_filter}))
    else:
        projects = list(projects_collection.find({'institution_name': institution_name}))

    return render_template('institution_projects.html', projects=projects, institution_name=institution_name)


if __name__ == '__main__':
    app.run(debug=True)
